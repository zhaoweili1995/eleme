<template>
  <div class="seller">
        <Top></Top>
        <GoodsList :products="products" :shopcartData="shopcartData"></GoodsList>
        <Shop-cart :shopcartData="shopcartData"></Shop-cart>
  </div>
</template>
<script>
import Top from './top/top'
import ShopCart from './shopCart/shopCart'
import GoodsList from './goodsList/GoodsList'
export default {
  data () {
    return {
      showCart: true,
      products: [],
      shopcartData: []
    }
  },
  computed: {
  },
  components: {
    Top,
    ShopCart,
    GoodsList
  },
  methods: {
    getGoods () {}
  }
}
</script>
<style lang="stylus" scoped>
.seller {
  position:absolute;
  overflow: hidden;
  z-index: 99;
  height: 100%;
  width:100%;
  background-color: #fff;
  top:0;
  left:0;
}
</style>
